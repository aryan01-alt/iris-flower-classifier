# 🌸 Iris Flower Classifier

A machine learning web application that classifies iris flowers into three species based on their measurements.

## 🚀 Features
- Interactive web interface built with Gradio
- Real-time predictions with confidence scores
- Trained on the classic Iris dataset
- Random Forest model with ~97% accuracy

## 🛠️ Installation
```bash
pip install -r requirements.txt
python app.py
```

## 📁 Project Structure
```
iris_classifier_project/
├── app.py
├── requirements.txt
├── models/
│   ├── iris_model.pkl
│   └── scaler.pkl
└── README.md
```

## 👨‍💻 Author
Your Name Here

## 📄 License
MIT License
