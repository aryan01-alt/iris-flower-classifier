import gradio as gr
import pickle
import numpy as np

# Load the trained model
with open('models/iris_model.pkl', 'rb') as f:
    model = pickle.load(f)

# Species names
species_names = ['Setosa', 'Versicolor', 'Virginica']

def classify_iris(sepal_length, sepal_width, petal_length, petal_width):
    """Classify iris flower based on measurements"""
    sample = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    prediction = model.predict(sample)
    probabilities = model.predict_proba(sample)[0]
    
    return {
        species_names[0]: float(probabilities[0]),
        species_names[1]: float(probabilities[1]),
        species_names[2]: float(probabilities[2])
    }

# Create Gradio interface
iface = gr.Interface(
    fn=classify_iris,
    inputs=[
        gr.Slider(4.0, 8.0, value=5.0, label="Sepal Length (cm)"),
        gr.Slider(2.0, 4.5, value=3.0, label="Sepal Width (cm)"),
        gr.Slider(1.0, 7.0, value=4.0, label="Petal Length (cm)"),
        gr.Slider(0.1, 2.5, value=1.0, label="Petal Width (cm)")
    ],
    outputs=gr.Label(num_top_classes=3),
    title="🌸 Iris Flower Classifier",
    description="Enter the measurements of an iris flower to predict its species.",
    examples=[
        [5.1, 3.5, 1.4, 0.2],
        [6.7, 3.0, 5.2, 2.3],
        [5.9, 3.0, 4.2, 1.5],
    ],
    theme=gr.themes.Soft()
)

if __name__ == "__main__":
    iface.launch()
